/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap1.deb2;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class TestTriangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        double x = 0.0;
        double y = 0.0;
        double w = 0.0;
        TrianguloRectangulo trianguloRectangulo1 = new  TrianguloRectangulo();
        System.out.print("Por favor, ingrese el valor del cateto N°1: ");
        x = entrada.nextDouble();
        trianguloRectangulo1.setCateto1(x);
        System.out.print("Por favor, ingrese el valor del cateto N°2: ");
        y = entrada.nextDouble();
        trianguloRectangulo1.setCateto2(y); 
        trianguloRectangulo1.calcularArea(x, y);
        trianguloRectangulo1.calcularHipotenusa(x, y);
        w = sqrt(pow(x,2.0)+pow(y,2.0));
        trianguloRectangulo1.calcularPerimetro(x, y, w);
        System.out.println("Por lo tanto, los valores del Triangulo Rectángulo 1 son: "+trianguloRectangulo1.toString());
              
    }
    
}
