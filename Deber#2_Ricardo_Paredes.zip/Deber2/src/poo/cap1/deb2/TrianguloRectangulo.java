/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap1.deb2;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 *
 * @author User
 */
public class TrianguloRectangulo {
    private double cateto1;
    private double cateto2;
    private double hipotenusa;
    private double area;
    private double perimetro;

    public void setCateto1(double cateto1) {
        this.cateto1 = cateto1;
    }

    public void setCateto2(double cateto2) {
        this.cateto2 = cateto2;
    }
    @Override
    public String toString() {
        return "TrianguloRectangulo{" + "cateto1 = " + cateto1 + ", cateto2 = " + cateto2 + ", hipotenusa = " + hipotenusa + ", area = " + area + ", perimetro=" + perimetro + '}';
    }
    public void calcularHipotenusa(double cateto1, double cateto2){
        this.hipotenusa=sqrt(pow(cateto1,2.0)+pow(cateto2,2.0));
    }
    public void calcularPerimetro(double cateto1,double cateto2,double hipotenusa){
        this.perimetro=cateto1+cateto2+hipotenusa;
    }
    public void calcularArea(double cateto1,double cateto2){
        this.area=(cateto1*cateto2)/2;
    }
   /* public double hipotenusa(){
        return this.hipotenusa();
    }*/
    
    
}
